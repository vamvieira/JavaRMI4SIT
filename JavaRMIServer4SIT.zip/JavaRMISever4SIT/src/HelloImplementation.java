
public class HelloImplementation implements HelloInterface
{
	public void printMessage()
	{
		System.out.println("teste JavaRMI");
	
	}
}
